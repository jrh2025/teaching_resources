# WebGL2 程序化三維地景在地化重構技能包 (`reconstruct-webgl2-terrain`)

本技能包完全遵循 **Google Gemini 系列應用程式技能官方規範（[support.google.com/gemini?p=pn_skills](https://support.google.com/gemini?p=pn_skills) 與 [編寫高效技能指南](https://support.google.com/gemini/answer/17102773)）** 設計，讓 Gemini 能根據指定的**任何地理區域、縣市鄉鎮、國家公園、海岸山脈或地圖路線航點**，一次產出**零外部資產（Zero-Asset）、單一 `.html` 即可執行的高寫實度 WebGL2 三維航拍地景互動系統**。

---

## ✅ Google Gemini 官方技能規範合規檢核表

| 官方規範項目 | 官方規定要求 (`support.google.com/gemini?p=pn_skills`) | 本技能包實作狀態 |
| :--- | :--- | :--- |
| **主資料夾中繼資料** | 專案必須在根（主）資料夾中包含 `SKILL.md` 檔案 | ✅ 符合（根目錄含 `SKILL.md`） |
| **技能命名慣例 (`name`)** | 以動詞開頭、全小寫英文字母並以連字號分隔 | ✅ `reconstruct-webgl2-terrain` |
| **技能說明 (`description`)** | 第三人稱陳述功能開頭、包含「`使用時機：`」、1024 字元內 | ✅ 148 字元（含第三人稱陳述與「`使用時機：`」） |
| **高效技能結構** | 包含進度檢查清單 (`[ ]`)、處理缺少資訊規則、輸出範本、常見錯誤 | ✅ 四大核心區塊完整內建於 `SKILL.md` |
| **支援檔案類型** | 僅使用官方支援副檔名：`.md`、`.json`、`.html`、`.py`、`.js` | ✅ 100% 符合（已將 `.mjs` 轉為標準 `.js`） |
| **安全與大小限制** | 總大小 `< 100 MB`、無外部網站請求指令碼、無 `.DS_Store`/`.pyc` 二進位檔 | ✅ 壓縮檔僅 `82 KB`、純離線腳本、零隱藏垃圾檔 |

---

## 📦 技能包目錄結構

```text
reconstruct-webgl2-terrain/
├── SKILL.md                                     # [必要] 技能主指令檔（含動詞開頭小寫名稱、使用時機、檢查清單與常見錯誤）
├── README.md                                    # 官方匯入步驟與使用說明文件
├── references/                                  # 進階 GLSL 數學與架構參考手冊 (.md)
│   ├── geomorphology_sdf_atlas.md               # 無迴圈噪聲、自然林相、街屋廟宇、校園跑道與海岸奇岩 3D SDF 圖鑑
│   ├── water_sky_optics_guide.md                # 午後黃金斜射光、瑞利大氣散射、尖峰衝浪泡沫網與溫泉/火光光學指南
│   └── ui_hud_and_soundscape_spec.md            # 三列式玻璃擬態 HUD、2D SDF 雷達瞬移、SPP=16 超取樣與四層空間聲景規範
├── templates/                                   # 地理分區與視線對齊規劃樣板 (.json)
│   └── region_blueprint_template.json           # 六區宏觀座標、攝影機視線對齊 (Framing) 與光學參數藍圖樣板
├── examples/                                    # 黃金實作完整參考範本 (.html)
│   └── webgl2_jinshan_coast_reference.html      # 完整 3,393 行單一 HTML 黃金範本（金山山海環狀線 6 區實作）
└── scripts/                                     # 本機離線品質驗證工具 (.py, .js)
    ├── validate_terrain_html.py                 # 28 項 WebGL2 結構、GLSL 算子、HUD 與零外部依賴靜態檢查腳本
    └── inspect_render.js                        # 本機 Headless Chrome/Edge 離線渲染與六區全航段截圖巡檢腳本
```

---

## 🚀 匯入與安裝方式（Installation）

### 方式一：上傳至 Google Gemini 網頁版 (`gemini.google.com`)
依據 Google 官方說明中心步驟：
1. 在電腦上前往 **[gemini.google.com](https://gemini.google.com)**。
2. 依序點擊側邊欄的「**選單**」圖示 ➔「**自訂 (Customize)**」➔ 頂端的「**技能 (Skills)**」。
3. 在「技能」頁面頂端，依序點擊「**建立 (Create)**」➔「**上傳 (Upload)**」。
4. 選取本技能包壓縮檔 **`reconstruct-webgl2-terrain.zip`**（或 `webgl2-terrain-reconstructor.zip`），點擊「**開啟 (Open)**」➔「**上傳 (Upload)**」。
5. 檢視技能名稱、說明與隨附參考檔案後，點擊頂端的「**建立 (Create)**」即可完成！
6. **在對話或任務中使用**：在對話框輸入 `/` 或 `@` 選取 `reconstruct-webgl2-terrain` 技能，或直接描述地景需求讓 Gemini 自動套用。

### 方式二：安裝至 Antigravity IDE / Gemini CLI
將壓縮檔解壓縮至以下任一目錄：
- **全域技能目錄**：`~/.gemini/config/skills/reconstruct-webgl2-terrain/`（Windows 為 `C:\Users\<使用者名稱>\.gemini\config\skills\reconstruct-webgl2-terrain\`）
- **專案工作區目錄**：`<專案根目錄>/.agents/skills/reconstruct-webgl2-terrain/`

---

## 💡 觸發與使用範例（Usage Examples）

1. **指定地圖路線與途經航點**：
   > 「請使用 reconstruct-webgl2-terrain 技能，根據『金美國小 ➔ 金包里老街 ➔ 獅頭山燭台雙嶼 ➔ 磺港漁港 ➔ 大鵬足湯公園 ➔ 中角灣衝浪基地』路線建立 WebGL2 三維航拍地景系統」
2. **指定台灣或全球特定地理區域**：
   > 「請幫我建立『花蓮太魯閣峽谷、燕子口、九曲洞至清水斷崖』的程序化 WebGL2 三維航拍地景 HTML 與重構指南」
   > 「請重構『阿里山森林鐵道、雲海、神木群與祝山日出』的 WebGL2 三維地景系統」
