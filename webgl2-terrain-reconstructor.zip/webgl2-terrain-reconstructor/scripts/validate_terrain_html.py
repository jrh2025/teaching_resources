#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WebGL2 程序化三維地景 HTML 靜態結構與寫實度強制規範驗證腳本
(validate_terrain_html.py)

用法：
    python validate_terrain_html.py <path_to_html_file>
"""

import re
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def validate_html(file_path: Path) -> int:
    if not file_path.exists():
        print(f"[錯誤] 找不到指定的檔案：{file_path}")
        return 1

    content = file_path.read_text(encoding="utf-8")
    lines = content.splitlines()
    print(f"============================================================")
    print(f"🔍 WebGL2 程序化地景系統靜態規範檢查：{file_path.name}")
    print(f"   檔案大小：{file_path.stat().st_size:,} bytes | 總行數：{len(lines):,} 行")
    print(f"============================================================")

    checks = [
        # 1. WebGL2 核心與五大著色器模組檢查
        ("WebGL2 著色器版本宣告 (#version 300 es)", r"#version\s+300\s+es"),
        ("v2_sky 大氣散射與程序化雲層函數 (computeSkyAndClouds / computeSky)", r"vec3\s+computeSky(?:AndClouds)?\s*\("),
        ("v3_geo 宏觀與微觀雙尺度地形評估函數 (evaluateTerrain)", r"vec[24]\s+evaluateTerrain\s*\(\s*vec3\s+\w+\s*,\s*bool\s+\w+\s*\)"),
        ("v3_geo 雙尺度分析法線函數 (calcTerrainNormal)", r"vec3\s+calcTerrainNormal\s*\("),
        ("v3_geo 雙尺度光線步進與二元搜尋精煉 (evaluateTerrain false/true)", r"evaluateTerrain\s*\([^,]+,\s*false\s*\)[\s\S]+evaluateTerrain\s*\([^,]+,\s*true\s*\)"),
        ("v3_geo 非週期不規則地籍扭曲算子 (evalIrregularParcel)", r"vec4\s+evalIrregularParcel\s*\("),
        ("v3_geo 2x2 快速 Voronoi 晶胞算子 (fastVoronoi2x2)", r"vec3\s+fastVoronoi2x2\s*\("),
        ("v3_geo 六大宏觀區域平滑權重函數 (getZoneMasks / computeZoneWeights)", r"(?:ZoneMasks\s+getZoneMasks|void\s+computeZoneWeights)\s*\("),
        ("v3_shade 材質分類、微法線與次表面散射著色器 (shadeTerrainSurface)", r"vec3\s+shadeTerrain(?:Surface)?\s*\("),
        ("v3_water 解析導數水體波浪法線算子 (noised / getWaterNormal)", r"vec3\s+(?:noised|getWaterNormal)\s*\("),
        ("v3_water 水體菲涅耳反射與折射著色器 (shadeWaterSurface)", r"vec3\s+shadeWater(?:Surface)?\s*\("),
        ("v1_post ACES Filmic 電影級色調映射函數 (acesToneMap / acesFilm)", r"vec3\s+aces(?:ToneMap|Film)\s*\("),

        # 2. HUD 三列式佈局與互動元件檢查
        ("三列式全視窗 HUD 容器 (#hudContainer)", r'id=["\']hudContainer["\']'),
        ("頂部遙測與工具列 (#hudTop)", r'id=["\']hudTop["\']'),
        ("2D 符號距離場雷達畫布 (#sdfRadarCanvas)", r'id=["\']sdfRadarCanvas["\']'),
        ("當前分區地質算子資訊欄 (#zoneGeoOp)", r'id=["\']zoneGeoOp["\']'),
        ("當前分區光學算子資訊欄 (#zoneShadeOp)", r'id=["\']zoneShadeOp["\']'),
        ("120秒航線時間軸滑桿 (#sliderTimeline)", r'id=["\']sliderTimeline["\']'),
        ("六區快速跳轉按鈕 (.zone-btn)", r'class=["\'][^"\']*zone-btn[^"\']*["\']'),
        ("GLSL 五大模組剖析視窗 (#shaderModal)", r'id=["\']shaderModal["\']'),
        ("操作與快捷鍵說明視窗 (#helpModal)", r'id=["\']helpModal["\']'),

        # 3. 進階渲染與音效功能檢查
        ("SPP=16 Halton 低差異序列超取樣函數 (halton)", r"function\s+halton\s*\("),
        ("WebGL 硬體常數 Alpha 累積混成 (CONSTANT_ALPHA)", r"gl\.CONSTANT_ALPHA"),
        ("Web Audio API 四層自然聲景控制器 (AudioContext)", r"AudioContext|webkitAudioContext"),
        ("粉紅噪聲海浪合成器 (pinkBuffer / createPinkNoiseBuffer)", r"pinkBuffer|createPinkNoiseBuffer"),
        ("立體聲隨機自然鳥鳴合成器 (playWetlandBirdCall / scheduleBirdChirp)", r"playWetlandBirdCall|scheduleBirdChirp"),
        ("2D SDF 雷達點擊瞬移事件綁定 (radarCanvas click)", r"(?:radarCanvas|sdfRadarCanvas)[\s\S]{0,600}addEventListener\s*\(\s*['\"]click['\"]"),
        ("零外部圖片或模型依賴 (禁止 .jpg/.png/.glb/.obj 外部請求)", r"^(?!.*(?:fetch|src)\s*\(\s*['\"]https?://.*\.(?:png|jpg|jpeg|glb|gltf|obj)).*$"),
    ]

    passed = 0
    failed = 0

    for title, pattern in checks:
        match = re.search(pattern, content, re.MULTILINE | re.DOTALL)
        if match:
            print(f"  ✅ [PASS] {title}")
            passed += 1
        else:
            print(f"  ❌ [FAIL] {title}  (未匹配規則: {pattern})")
            failed += 1

    # 額外進階寫實度指標報告（Informational Realism & Fast-Compile Metrics）
    has_townhouse = bool(re.search(r"evalTownhouseCluster", content))
    has_natural_tree = bool(re.search(r"evalNaturalTreeCanopy", content))
    print(f"------------------------------------------------------------")
    print(f"🌟 進階寫實度算子偵測：")
    print(f"   - Lipschitz 連續街屋/廟宇聚落算子 (evalTownhouseCluster): {'已啟用' if has_townhouse else '未啟用（適用於城鎮/老街航線）'}")
    print(f"   - 無迴圈自然樹冠簇算子 (evalNaturalTreeCanopy): {'已啟用' if has_natural_tree else '未啟用（適用於山林/海岸航線）'}")
    print(f"------------------------------------------------------------")
    print(f"📊 檢查總結：通過 {passed}/{len(checks)} 項 | 失敗 {failed} 項")
    print(f"============================================================")

    return 0 if failed == 0 else 2


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python validate_terrain_html.py <path_to_html_file>")
        sys.exit(1)

    target = Path(sys.argv[1]).resolve()
    sys.exit(validate_html(target))
