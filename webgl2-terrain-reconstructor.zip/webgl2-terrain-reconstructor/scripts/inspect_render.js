/**
 * WebGL2 程序化地景系統本機離線渲染與六區視覺巡檢腳本
 * (inspect_render.js — 符合 Gemini Skills .js 支援檔案規範與離線安全限制)
 *
 * 用法：
 *   1. 單一時間點截圖（保留 HUD）：
 *      node inspect_render.js <html_path> <output_png_path> [query_params]
 *      範例：node inspect_render.js webgl2_jinshan_coast.html preview.png "t=32&scale=1.0"
 *
 *   2. 六大宏觀分區全航段無遮擋地景巡檢（自動隱藏 HUD 並於本機擷取 6 張分區代表圖）：
 *      node inspect_render.js <html_path> <output_prefix_png_path> --all-zones
 *      範例：node inspect_render.js webgl2_jinshan_coast.html zone_check.png --all-zones
 */

const { spawn } = require('child_process');
const fs = require('fs');
const http = require('http');
const path = require('path');

const htmlArg = process.argv[2];
const outArg = process.argv[3] || 'render_preview.png';
const modeOrQuery = process.argv[4] || 't=68&scale=1.0';

if (!htmlArg) {
  console.error('用法: node inspect_render.js <html_path> <output_png_path> [query_params | --all-zones]');
  process.exit(1);
}

const isAllZones = modeOrQuery === '--all-zones';
const htmlPath = path.resolve(htmlArg);
const outPath = path.resolve(outArg);
const rootDir = path.dirname(htmlPath);
const htmlFileName = path.basename(htmlPath);

const CHROME_CANDIDATES = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium-browser',
];

const chromePath = CHROME_CANDIDATES.find((p) => fs.existsSync(p));
if (!chromePath) {
  console.error('[錯誤] 找不到本機 Chrome 或 Edge 執行檔');
  process.exit(1);
}

// 僅綁定本機迴路 127.0.0.1 提供待測 HTML 檔案，不進行任何外部網路連線
const server = http.createServer((req, res) => {
  const cleanUrl = req.url.split('?')[0];
  const targetFile = cleanUrl === '/' ? htmlPath : path.join(rootDir, cleanUrl);
  fs.readFile(targetFile, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    const ext = path.extname(targetFile).toLowerCase();
    const mime = ext === '.html' ? 'text/html; charset=utf-8' : 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime });
    res.end(data);
  });
});

function captureAtTime(httpPort, queryStr, targetPng) {
  return new Promise((resolve, reject) => {
    const userDataDir = path.join(process.env.TEMP || '/tmp', `chrome_webgl_inspect_${Date.now()}_${Math.random().toString(36).slice(2)}`);
    const targetUrl = `http://127.0.0.1:${httpPort}/${htmlFileName}?${queryStr}`;
    const chrome = spawn(chromePath, [
      `--user-data-dir=${userDataDir}`,
      '--headless=new',
      '--window-size=1440,900',
      '--enable-webgl',
      '--ignore-gpu-blocklist',
      '--use-angle=d3d11',
      '--no-first-run',
      '--virtual-time-budget=3500',
      `--screenshot=${targetPng}`,
      targetUrl,
    ]);

    chrome.on('close', (code) => {
      if (fs.existsSync(targetPng)) {
        console.log(`[成功] 驗證截圖已儲存至: ${targetPng}`);
        resolve();
      } else {
        reject(new Error(`截圖失敗 (exit code: ${code})`));
      }
    });
  });
}

server.listen(0, '127.0.0.1', async () => {
  const httpPort = server.address().port;
  try {
    if (!isAllZones) {
      await captureAtTime(httpPort, modeOrQuery, outPath);
    } else {
      const zoneTimes = [5, 14, 32, 52, 72, 92];
      const parsedOut = path.parse(outPath);
      for (let i = 0; i < zoneTimes.length; i++) {
        const t = zoneTimes[i];
        const zoneOutPath = path.join(
          parsedOut.dir,
          `${parsedOut.name}_zone${i + 1}_t${t}${parsedOut.ext || '.png'}`
        );
        await captureAtTime(httpPort, `t=${t}&scale=1.0`, zoneOutPath);
      }
    }
  } catch (err) {
    console.error('[異常]', err.message);
    process.exitCode = 1;
  } finally {
    server.close();
  }
});
