/**
 * WebGL2 程序化地景系統無頭瀏覽器自動化渲染與六區視覺巡檢腳本
 * (inspect_render.mjs)
 *
 * 用法：
 *   1. 單一時間點截圖（保留 HUD）：
 *      node inspect_render.mjs <html_path> <output_png_path> [query_params]
 *      範例：node inspect_render.mjs webgl2_jinshan_coast.html preview.png "t=32&scale=1.0"
 *
 *   2. 六大宏觀分區全航段無遮擋地景巡檢（自動隱藏 HUD 並於單一瀏覽器階段擷取 6 張分區代表圖）：
 *      node inspect_render.mjs <html_path> <output_prefix_png_path> --all-zones
 *      範例：node inspect_render.mjs webgl2_jinshan_coast.html zone_check.png --all-zones
 */

import { spawn } from 'child_process';
import fs from 'fs';
import http from 'http';
import path from 'path';
import WebSocket from 'ws';

const htmlArg = process.argv[2];
const outArg = process.argv[3] || 'render_preview.png';
const modeOrQuery = process.argv[4] || 't=68&scale=1.0';

if (!htmlArg) {
  console.error('用法: node inspect_render.mjs <html_path> <output_png_path> [query_params | --all-zones]');
  process.exit(1);
}

const isAllZones = modeOrQuery === '--all-zones';
const htmlPath = path.resolve(htmlArg);
const outPath = path.resolve(outArg);
const rootDir = path.dirname(htmlPath);
const htmlFileName = path.basename(htmlPath);

const CHROME_CANDIDATES = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
];

const chromePath = CHROME_CANDIDATES.find((p) => fs.existsSync(p));
if (!chromePath) {
  console.error('[錯誤] 找不到 Chrome 或 Edge 執行檔');
  process.exit(1);
}

const server = http.createServer((req, res) => {
  const cleanUrl = req.url.split('?')[0];
  const targetFile = cleanUrl === '/' ? htmlPath : path.join(rootDir, cleanUrl);
  fs.readFile(targetFile, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    const ext = path.extname(targetFile).toLowerCase();
    const mime = ext === '.html' ? 'text/html; charset=utf-8' : 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime });
    res.end(data);
  });
});

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function getWsEndpoint(port) {
  for (let i = 0; i < 40; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/json/list`);
      const pages = await res.json();
      const page = pages.find((p) => p.type === 'page' && p.webSocketDebuggerUrl);
      if (page) return page.webSocketDebuggerUrl;
    } catch (_) {}
    await sleep(200);
  }
  throw new Error('無法連線至 Chrome DevTools WebSocket');
}

server.listen(0, '127.0.0.1', async () => {
  const httpPort = server.address().port;
  const debugPort = 9330 + Math.floor(Math.random() * 500);
  const userDataDir = path.join(process.env.TEMP || '.', `chrome_webgl_inspect_${Date.now()}`);
  const initialQuery = isAllZones ? 't=5&scale=1.0' : modeOrQuery;
  const targetUrl = `http://127.0.0.1:${httpPort}/${htmlFileName}?${initialQuery}`;

  console.log(`[啟動] 載入網址: ${targetUrl}`);
  const chrome = spawn(chromePath, [
    `--remote-debugging-port=${debugPort}`,
    `--user-data-dir=${userDataDir}`,
    '--headless=new',
    '--window-size=1440,900',
    '--enable-webgl',
    '--ignore-gpu-blocklist',
    '--use-angle=d3d11',
    '--no-first-run',
    targetUrl,
  ]);

  try {
    const wsUrl = await getWsEndpoint(debugPort);
    const ws = new WebSocket(wsUrl);
    await new Promise((resolve, reject) => {
      ws.once('open', resolve);
      ws.once('error', reject);
    });

    let msgId = 1;
    const pending = new Map();
    const consoleErrors = [];

    ws.on('message', (raw) => {
      const data = JSON.parse(raw.toString());
      if (data.method === 'Runtime.consoleAPICalled' && data.params.type === 'error') {
        consoleErrors.push(data.params.args.map((a) => a.value || a.description).join(' '));
      }
      if (data.method === 'Runtime.exceptionThrown') {
        consoleErrors.push(data.params.exceptionDetails.text);
      }
      if (data.id && pending.has(data.id)) {
        pending.get(data.id)(data);
        pending.delete(data.id);
      }
    });

    const sendCmd = (method, params = {}) =>
      new Promise((resolve) => {
        const id = msgId++;
        pending.set(id, resolve);
        ws.send(JSON.stringify({ id, method, params }));
      });

    await sendCmd('Page.enable');
    await sendCmd('Runtime.enable');
    await sleep(3200);

    const evalRes = await sendCmd('Runtime.evaluate', {
      expression: `(() => {
        const c = document.getElementById('glCanvas');
        const btnPause = document.getElementById('btnPlayPause');
        if (btnPause && btnPause.textContent.includes('暫停')) btnPause.click();
        const zoneBtns = Array.from(document.querySelectorAll('.zone-btn')).map(b => ({
          zone: b.getAttribute('data-zone'),
          time: Number(b.getAttribute('data-time') || 10),
          label: b.textContent.trim()
        }));
        return {
          canvasWidth: c ? c.width : 0,
          canvasHeight: c ? c.height : 0,
          zoneTitle: document.getElementById('zoneCardTitle')?.textContent || '',
          telemetryPos: document.getElementById('telemetryPos')?.textContent || '',
          zoneBtns
        };
      })()`,
      returnByValue: true,
    });

    const info = evalRes.result?.result?.value || {};
    console.log('[狀態] 畫布尺寸:', `${info.canvasWidth}x${info.canvasHeight}`);
    console.log('[狀態] 當前分區標題:', info.zoneTitle);
    console.log('[狀態] 無人機遙測座標:', info.telemetryPos);

    if (consoleErrors.length > 0) {
      console.error('[錯誤] 偵測到瀏覽器執行期或 GLSL 錯誤:', consoleErrors);
      process.exitCode = 2;
    }

    if (!isAllZones) {
      const shot = await sendCmd('Page.captureScreenshot', { format: 'png' });
      if (shot.result?.data) {
        fs.writeFileSync(outPath, Buffer.from(shot.result.data, 'base64'));
        console.log(`[成功] 驗證截圖已儲存至: ${outPath}`);
      }
    } else {
      await sendCmd('Runtime.evaluate', {
        expression: `(() => {
          const hud = document.getElementById('hudContainer');
          if (hud) hud.style.display = 'none';
        })()`,
      });

      const zones =
        info.zoneBtns && info.zoneBtns.length > 0
          ? info.zoneBtns
          : [
              { zone: '1', time: 5, label: 'Zone 1' },
              { zone: '2', time: 14, label: 'Zone 2' },
              { zone: '3', time: 32, label: 'Zone 3' },
              { zone: '4', time: 52, label: 'Zone 4' },
              { zone: '5', time: 72, label: 'Zone 5' },
              { zone: '6', time: 92, label: 'Zone 6' },
            ];

      const parsedOut = path.parse(outPath);
      for (const z of zones) {
        await sendCmd('Runtime.evaluate', {
          expression: `(() => {
            const slider = document.getElementById('sliderTimeline');
            if (slider) {
              slider.value = '${z.time}';
              slider.dispatchEvent(new Event('input', { bubbles: true }));
            }
          })()`,
        });
        await sleep(550);
        const shot = await sendCmd('Page.captureScreenshot', { format: 'png' });
        if (shot.result?.data) {
          const zoneOutPath = path.join(
            parsedOut.dir,
            `${parsedOut.name}_zone${z.zone}_t${z.time}${parsedOut.ext || '.png'}`
          );
          fs.writeFileSync(zoneOutPath, Buffer.from(shot.result.data, 'base64'));
          console.log(`[成功] 分區 ${z.zone} (${z.label}, t=${z.time}s) 截圖已儲存至: ${zoneOutPath}`);
        }
      }
    }

    ws.close();
  } catch (err) {
    console.error('[異常]', err);
    process.exitCode = 1;
  } finally {
    chrome.kill();
    server.close();
  }
});
