# 水體光學、衝浪碎浪泡沫、大氣散射與微材質著色指南 (`water_sky_optics_guide.md`)

本指南定義 `v2_sky`、`v3_shade`、`v3_water` 與 `v1_post` 四大光學模組的實作標準，確保地景系統具備電影級的大氣光影、真實海洋碎浪層次與水體物理反射。

---

## 一、`v2_sky`：午後黃金斜射光、瑞利—米氏散射與雙層程序化雲系

> [!IMPORTANT]
> **太陽仰角鐵律**：預設太陽仰角 `u_sunEl` 嚴禁高於 `25°`（正午頂光會使地形法線 `dot(N, sunDir) ≈ 1.0`，導致山脊、屋瓦、田埂失去立體陰影，且米氏前向散射會將天空洗白）。
> - **山海海岸與聚落航線建議預設值**：`sunEl = 16.0° ~ 19.0°`（午後黃金斜陽，兼顧湛藍海灣、翠綠山林與建築立面長陰影）。
> - **西部潟湖與鹽田夕照建議預設值**：`sunEl = 6.5° ~ 9.0°`（低角度晚霞逆光，強化水田滷水鏡面金光）。

1. **天頂與地平線光譜漸層**：
   - 隨太陽仰角 `sunEl` 動態調整天頂深鈷藍（`vec3(0.08, 0.24, 0.54)`）與地平線暖金霞光（`vec3(0.86, 0.58, 0.34)`）。
   - 米氏散射（Mie Scattering）相位函數：
     ```glsl
     float mu = max(dot(rd, sunDir), 0.0);
     float mie = pow(mu, 8.0) * 0.32 * u_haze + pow(mu, 96.0) * 0.65;
     ```
2. **雙層程序化雲系（Cirrus + Cumulus）**：
   - 以平面投影座標 `vec2 uv = rd.xz / (rd.y + 0.14)` 結合 `fbm3` 計算雲層密度 `cloud`；
   - 以太陽方向偏移採樣計算雲底自陰影 `cloudShadow`，在向陽側疊加金邊散射（Silver-lining），提升天空景深。
3. **漸進式遠景瑞利大氣透視（Delayed Aerial Perspective Fog）**：
   - 嚴禁對 `180m` 以內的近中景施加濃霧（否則建築與草木會發灰混濁）。必須採用延遲距離霧化公式：
     ```glsl
     float fogDist = max(0.0, hitDist - 180.0);
     float fogFactor = 1.0 - exp(-fogDist * 0.000034 * u_haze);
     vec3 finalCol = mix(surfaceCol, skyHorizonCol, clamp(fogFactor, 0.0, 0.72));
     ```

---

## 二、`v3_water`：多區水體波浪、衝浪灣碎浪泡沫網與溫泉/火光光學

在同一張地圖中，必須根據座標分區與水深 `waterDepth = max(0.0, -terrainH)` 混合至少 4 種不同的水體物理狀態：

1. **分區波浪頻率與振幅 (`getWaterNormal`)**：
   - **外海與衝浪海灣（如中角灣、台灣海峽）**：長週期湧浪疊加向岸推進相位 `sin(xz.z * 0.12 - time * 2.2 + fbm3(xz * 0.02) * 2.5)`，波紋幅度 `1.0x`；
   - **海岬暗礁與海蝕柱水域**：雙向繞射疊浪，波紋幅度 `0.85x`；
   - **漁港泊地與內海潟湖**：受防波堤或沙洲遮蔽之平緩微波，波紋幅度 `0.22x`；
   - **內陸溪流、大圳與瓦盤鹽田**：順應河道走向之細密流紋或靜態高反射滷水鏡面，波紋幅度 `0.08x ~ 0.15x`。

2. **衝浪灣非對稱尖峰碎浪與碎形泡沫網 (`surfRollerFoam`)**：
   > [!CAUTION]
   > 嚴禁直接使用均勻正弦波 `sin(z)` 畫出平行白線，否則在空中俯瞰會像人工斑馬線！必須結合海灣包絡遮罩、非對稱尖峰波函數與碎形泡沫孔洞噪聲：
   ```glsl
   // 1. 衝浪灣海域包絡遮罩（限制於海灣水深 0.15m ~ 3.2m 區間）
   float bayMask = smoothstep(5400.0, 6200.0, p.x) * (1.0 - smoothstep(8200.0, 9100.0, p.x))
                 * smoothstep(0.08, 0.35, waterDepth) * (1.0 - smoothstep(1.8, 3.5, waterDepth));
   // 2. 受不規則海岸線扭曲的向岸湧浪相位
   float warpWave = fbm3(p.xz * 0.018 + vec2(u_time * 0.12, 0.0)) * 3.2;
   float swellPhase = p.z * 0.11 + u_time * 2.1 + warpWave;
   // 3. 非對稱尖峰浪冠 + 浪尾拖曳泡沫網
   float crestPeak = pow(max(0.0, sin(swellPhase)), 6.0);
   float foamLace  = smoothstep(0.36, 0.68, fbm3(p.xz * 0.28 + vec2(0.0, u_time * 0.6)));
   float surfRollerFoam = bayMask * crestPeak * (0.55 + 0.45 * foamLace);
   ```

3. **海蝕柱/暗礁同心圓繞射碎浪環 (`twinBreaker`) 與精準岸際浪花 (`shoreFoam`)**：
   ```glsl
   // 雙海蝕柱基座同心圓向外擴散之白色激浪環
   float dTwin = min(length(p.xz - stack1XZ), length(p.xz - stack2XZ));
   float ringWave = pow(max(0.0, sin(dTwin * 0.32 - u_time * 2.6 + fbm3(p.xz * 0.08) * 2.0)), 4.0);
   float twinBreaker = smoothstep(48.0, 14.0, dTwin) * smoothstep(6.0, 14.0, dTwin) * ringWave;

   // 岸際拍岸浪花（嚴格限制於 waterDepth < 0.32m 的真實水陸交界線）
   float shoreFoam = smoothstep(0.32, 0.0, waterDepth)
                   * (0.55 + 0.45 * sin(waterDepth * 26.0 - u_time * 3.4 + fbm3(p.xz * 0.22) * 3.0));
   ```

4. **特色在地水體光學（海底溫泉鐵泉羽流 & 漁港蹦火仔火光倒影）**：
   - **海底溫泉「黃金之湯」熱羽流 (`thermalPlume`)**：在潮間帶湧泉池與外溢海域混合琥珀金黃氧化鐵泉色 `vec3(0.78, 0.52, 0.16)`，疊加隨時間搖曳的乳白硫磺泉華羽流。
   - **漁港「蹦火仔」電石火光 (`boatGlow`)**：在磺火漁船船頭前方水體疊加熾熱青白—橙金點光源反射 `exp(-dBoatFront * 0.06) * vec3(1.15, 0.72, 0.28)`，重現國家級無形文化資產的視覺焦點。

---

## 三、`v3_shade`：微法線擾動、植被次表面散射與建築材質細節

1. **植被次表面散射（Back-lit Subsurface Scattering）與絲絨邊緣光**：
   - 針對防風林、丘陵闊葉林、芒草、稻浪、甘蔗與番薯葉（`matID = 5.0 / 6.0 / 7.0`）：
     ```glsl
     float backLit = pow( clamp(dot(rd, -sunDir), 0.0, 1.0), 3.0 );
     float grazing = pow( 1.0 - max(dot(N, -rd), 0.0), 2.5 );
     vec3 sssContribution = sunColor * sssStrength * (backLit * 0.65 + grazing * 0.35);
     ```
2. **潮間帶綠石蓴（Sea Lettuce）與濕潤黑玄武岩微閃光**：
   - 在豆腐岩、海蝕平台與防波堤靠近水面處（`p.y < 0.85m`），依據 `fbm3(p.xz * 0.45)` 疊加鮮翠海藻綠石蓴色帶 `vec3(0.18, 0.48, 0.16)`，並提高濕潤岩面鏡面高光（Specular `pow(NdotH, 48.0)`）。
3. **火山崩壁硫磺結晶與地熱蒸氣**：
   - 在背景火山爆裂口（如小油坑、庚子坪）區域，依據坡度與高度混入明黃硫磺結晶斑塊 `vec3(0.82, 0.74, 0.22)` 與灰白矽化安山岩，營造強烈的地質對比。
