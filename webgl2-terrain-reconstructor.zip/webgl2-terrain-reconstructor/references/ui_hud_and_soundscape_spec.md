# 三列式玻璃擬態 HUD、2D SDF 雷達與四層空間聲景規範 (`ui_hud_and_soundscape_spec.md`)

本規範定義單一 HTML 地景系統的前端互動介面、2D 符號距離場雷達圖、SPP 超取樣渲染器與 Web Audio API 自然聲景合成器標準架構，確保所有產出的地景系統兼具專業圖形學工程品質與直覺的使用者體驗。

---

## 一、不重疊三列式全視窗 Flex HUD 骨架 (`#hudContainer`)

為確保在各種螢幕尺寸下控制面板絕不互相遮擋，HTML 必須採用固定三列式（Top / Middle / Bottom）Flexbox 佈局：

1. **第一列：頂部遙測與工具列 (`#hudTop`)**
   - **左側品牌與分區標題**：顯示系統主標題、`Zero-Asset WebGL2` 徽章，以及隨時間/座標即時更新的 `#activeZoneSubtitle`。
   - **中央即時著色器遙測 (`#telemetryPos`, `#telemetryMasks`, `#telemetryPerf`)**：即時顯示無人機世界座標 `(X, Y, Z)`、當前位置四大/六大宏觀分區權重，以及即時 FPS 與渲染解析度倍率。
   - **右側功能按鈕列**：
     - `⚡ 極速省電` (`#btnPerfBoost`)：一鍵切換 `0.45x` 解析度與高速步進。
     - `史詩航線運鏡 / 自由飛行模式` (`#btnToggleCameraMode`)。
     - `SPP 靜態渲染` (`#btnToggleStillMode`)：觸發 `SPP=16` Halton 次像素超取樣累積渲染。
     - `GLSL 管線剖析` (`#btnOpenShaderModal`)：開啟五大著色器模組原始碼與數學解說視窗。
     - `🔇/🔊 聲景` (`#btnToggleAudio`)：開關四層動態自然聲景。
     - `❓ 操作說明` (`#btnOpenHelpModal`)、`隱藏面板 (H)` (`#btnToggleUI`)、`⛶ 全螢幕 (F)` (`#btnFullscreen`)。

2. **第二列：中段左右側邊欄 (`#hudMiddle`)**
   - **左側邊欄 (`#hudLeft`)**：
     - **2D 符號距離場與宏觀分區雷達 (`#sdfRadarCanvas`, `300x144`)**：離線預計算整個區域（如 `26km x 2km`）的海陸分佈、河道曲流、沙洲、鹽田、森林與地標色塊，疊加黃色虛線航線軌跡與無人機即時位置/視錐扇形；**支援滑鼠點擊任意位置直接瞬移無人機**。
     - **當前分區地質與光學資訊卡**：動態更新 `#zoneCardBadge`、`#zoneWaterBadge`、`#zoneCardTitle`、`#zoneCardDesc`、`#zoneGeoOp`（`v3_geo` 幾何算子）與 `#zoneShadeOp`（`v3_shade` 材質光學算子）。
   - **右側邊欄 (`#hudRight`)**：
     - **即時光學與著色器調參面板**：提供 8 組滑桿（太陽仰角 `1.5°~45°`、太陽方位角 `180°~310°`、大氣渾濁度 `0.4~3.0`、體積雲密度 `0.0~1.0`、水體波浪強度 `0.2~2.0`、微地形浮雕高度 `0.3x~2.5x`、動態步進品質 `1~3`、畫面解析度 `0.45x~1.25x`）、3 組勾選開關（解析平面求交、立體植栽/地標、低於 35 FPS 自動降載保護），以及 URL 參數即時顯示與複製按鈕（`#urlQueryReadout` / `#btnCopyUrl`）。

3. **第三列：底部 120 秒史詩航線時間軸與六區快速跳轉列 (`#hudBottom`)**
   - 頂部附帶可收合之操作提示膠囊 (`#quickHintBanner`)。
   - **六區快速跳轉按鈕 (`.zone-btn`)**：對應 6 個地理分區的代表時間點（例如 `5s, 30s, 50s, 71s, 93s, 114s`），同時綁定鍵盤數字鍵 `1 ~ 6`。
   - **時間軸滑桿 (`#sliderTimeline`, `0s ~ 120s`)** 與播放/暫停按鈕 (`#btnPlayPause`)，下方標註 6 個關鍵航段時間地標。

---

## 二、SPP=16 次像素抖動超取樣靜態渲染模式 (`mode=still`)

比照 `napali-main` 的離線高品質靜態幀機制，當使用者點擊「SPP 靜態渲染」或帶入 URL 參數 `?mode=still&spp=16` 時：
1. 暫停時間推進，將畫布解析度鎖定為 `1.0x` 原生視窗解析度。
2. 每一幀使用 **Halton 低差異序列（Base 2, Base 3）** 產生次像素抖動偏移 `u_jitter = vec2(halton(sppCount, 2), halton(sppCount, 3))`。
3. 透過 WebGL 硬體常數 Alpha 混成：
   ```javascript
   gl.enable(gl.BLEND);
   gl.blendFunc(gl.CONSTANT_ALPHA, gl.ONE_MINUS_CONSTANT_ALPHA);
   gl.blendColor(0, 0, 0, 1.0 / state.sppCount);
   ```
   連續累積 16 幀後自動停止 GPU 繪製（`shouldDraw = false`），消除所有遠景邊緣鋸齒與光線步進噪訊。當滑鼠拖曳視角或調整任何光學滑桿時，自動呼叫 `resetStillAccumulation()` 重新累積。

---

## 三、四層動態空間自然聲景合成器 (Web Audio API)

不載入任何外部音訊檔案，完全以 Web Audio API 即時合成與地景空間位置連動的四層環境音：
1. **第一層：粉紅噪聲（Pink Noise）海浪潮汐 / 瀑布溪流聲**
   - 使用 Paul Kellet 濾波公式生成溫暖自然的 4 秒雙聲道粉紅噪聲循環緩衝區。
   - 透過低通濾波器（Lowpass `BiquadFilter`）搭配約 8 秒週期的正弦 LFO 調變截止頻率（`150Hz ~ 570Hz`）與音量，並隨無人機靠近海岸/河谷的空間權重 `coastalFactor` 動態放大。
2. **第二層：微風吹拂芒草 / 樹林 / 稻浪沙沙聲**
   - 以帶通濾波器（Bandpass `BiquadFilter`, `Q = 1.8`, `520Hz ~ 1000Hz`）調變粉紅噪聲，隨內陸/山林權重 `inlandFactor` 增強。
3. **第三層：溫暖環境泛音和弦（Sunset / Mountain Harmonic Pad）**
   - 由 4 組微調諧（Detuned）之正弦波與三角波振盪器（例如 `F3 - C4 - G4 - A4`：174.61Hz, 261.63Hz, 392.00Hz, 440.00Hz）通過 `340Hz` 低通濾波器，營造遼闊寧靜的空間氛圍。
4. **第四層：隨機立體聲自然鳥鳴合成器（Procedural Birdsong）**
   - 以五聲音階高頻正弦波（`1760Hz ~ 3136Hz`）配合指數頻率滑音與 StereoPanner 左右聲道隨機定位，每 3.8 秒隨機觸發清脆的濕地水鳥或山林鳥鳴。
