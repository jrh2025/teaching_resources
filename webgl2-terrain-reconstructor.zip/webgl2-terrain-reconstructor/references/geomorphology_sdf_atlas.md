# 程序化地貌、自然林相與真實建築地標 3D SDF 算子圖鑑 (`geomorphology_sdf_atlas.md`)

本參考文件彙整經過大北門鹽分地帶與金山山海環狀線實戰驗證的 GLSL ES 3.0 核心地貌與建築符號距離場（SDF）算子庫。在為任何新地理區域（如九份金瓜石、太魯閣清水斷崖、阿里山、日月潭等）建構 `v3_geo` 與 `v3_shade` 時，請直接取用並根據當地真實地景微調這些模組。

---

## 一、無迴圈快速編譯噪聲與非週期地籍扭曲算子（Loop-Free Noise & Domain Warping）

> [!IMPORTANT]
> Windows Chrome 的 ANGLE D3D11 (`fxc.exe`) 編譯器在展開 `evaluateTerrain` 時，若 `fbm3`、`ridgedNoise` 或 `fastVoronoi2x2` 內部含有 `for` 迴圈，會產生 $O(N^2)$ 的指令展開延遲。因此所有底層噪聲與晶胞函數**必須展開為無迴圈之直線算式（Loop-Free Unrolled Expressions）**。

### 1. 無迴圈三階 FBM、山脊噪聲與 2x2 Voronoi 晶胞 (`fbm3`, `ridgedNoise`, `fastVoronoi2x2`)
```glsl
const mat2 ROT2 = mat2(0.80, -0.60, 0.60, 0.80);

// 無迴圈 3-Octave FBM（秒級編譯優化）
float fbm3(vec2 p) {
    float v = 0.5000 * valueNoise(p); p = ROT2 * p * 2.02;
    v += 0.2500 * valueNoise(p);      p = ROT2 * p * 2.03;
    v += 0.1250 * valueNoise(p);
    return v;
}

// 無迴圈 3-Octave 尖銳山脊/蝕溝噪聲（適用於火山放射狀蝕溝、惡地與海蝕崖）
float ridgedNoise(vec2 p) {
    float n0 = 1.0 - abs(valueNoise(p) * 2.0 - 1.0); p = ROT2 * p * 2.05;
    float n1 = 1.0 - abs(valueNoise(p) * 2.0 - 1.0); p = ROT2 * p * 2.05;
    float n2 = 1.0 - abs(valueNoise(p) * 2.0 - 1.0);
    return n0 * n0 * 0.50 + n1 * n1 * 0.25 + n2 * n2 * 0.125;
}

// 無迴圈雙頻空間扭曲
vec2 fastDomainWarp(vec2 p, float amp) {
    vec2 q = vec2(valueNoise(p * 0.013), valueNoise(p * 0.013 + vec2(5.2, 1.3)));
    return p + (q - 0.5) * amp;
}

// 無迴圈 2x2 快速 Voronoi 晶胞（回傳 vec3(最近距離F1, 邊界距離F2-F1, 晶胞雜湊ID)）
vec3 fastVoronoi2x2(vec2 x) {
    vec2 n = floor(x);
    vec2 f = fract(x);
    float md1 = 8.0, md2 = 8.0, bestId = 0.0;

    vec2 g, o, r; float d;
    g = vec2(0.0, 0.0); o = hash22(n + g); r = g + (0.18 + 0.64 * o) - f; d = dot(r, r);
    if (d < md1) { md2 = md1; md1 = d; bestId = hash21(n + g); } else if (d < md2) { md2 = d; }

    g = vec2(1.0, 0.0); o = hash22(n + g); r = g + (0.18 + 0.64 * o) - f; d = dot(r, r);
    if (d < md1) { md2 = md1; md1 = d; bestId = hash21(n + g); } else if (d < md2) { md2 = d; }

    g = vec2(0.0, 1.0); o = hash22(n + g); r = g + (0.18 + 0.64 * o) - f; d = dot(r, r);
    if (d < md1) { md2 = md1; md1 = d; bestId = hash21(n + g); } else if (d < md2) { md2 = d; }

    g = vec2(1.0, 1.0); o = hash22(n + g); r = g + (0.18 + 0.64 * o) - f; d = dot(r, r);
    if (d < md1) { md2 = md1; md1 = d; bestId = hash21(n + g); } else if (d < md2) { md2 = d; }

    float s1 = sqrt(md1);
    float s2 = sqrt(md2);
    return vec3(s1, s2 - s1, bestId);
}
```

### 2. 非週期不規則地籍與梯田分塊 (`evalIrregularParcel`)
適用於：台灣農田（甘蔗、稻田、番薯、高粱、花海）、河階梯田、不規則養殖魚塭與傳統瓦盤鹽田。
```glsl
// 回傳 vec4(bermMask: 田埂遮罩, parcelId: 地籍雜湊ID, localU: 區塊內U, localV: 區塊內V)
vec4 evalIrregularParcel(vec2 xz, float scaleX, float scaleZ, float warpAmp, float bermWidth) {
    vec2 warp = vec2(
        valueNoise(xz * 0.0028 + vec2(1.7, 9.2)) - 0.5,
        valueNoise(xz * 0.0028 + vec2(8.3, 2.8)) - 0.5
    ) * warpAmp;
    vec2 warped = xz + warp;

    // 結合在地真實主幹道走向旋轉角度（例如 22 度）
    float ang = 0.38;
    mat2 rot = mat2(cos(ang), -sin(ang), sin(ang), cos(ang));
    vec2 uv = (rot * warped) * vec2(scaleX, scaleZ);

    // 奇偶列交錯偏移（Running-bond Row Shift），徹底消除十字交叉網格
    float rowIdx = floor(uv.y);
    float rowShift = hash21(vec2(rowIdx, 19.3)) * 0.65;
    uv.x += rowShift;

    vec2 cellId = floor(uv);
    vec2 f = fract(uv);
    float pId = hash21(cellId);

    float edgeDist = min(min(f.x, 1.0 - f.x), min(f.y, 1.0 - f.y));
    float bermMask = 1.0 - smoothstep(0.0, bermWidth, edgeDist);
    return vec4(bermMask, pId, f.x, f.y);
}
```

---

## 二、無迴圈自然樹冠簇與防風林算子（Loop-Free Organic Tree Canopies）

嚴禁使用均勻正弦波圓球顆粒（`sin(x)*sin(z)`）模擬樹木！以下無迴圈 `evalNaturalTreeCanopy` 透過雙頻空間扭曲與三組非對稱樹冠頻率疊加，能生成具備疏密聚落與枝葉凹凸的真實台灣亞熱帶闊葉林、木麻黃防風林與海岸灌木叢：

```glsl
float evalNaturalTreeCanopy(vec2 xz) {
    vec2 wp = fastDomainWarp(xz, 28.0);
    // 大型林班疏密分佈遮罩
    float groveMask = smoothstep(0.32, 0.66, valueNoise(wp * 0.016 + vec2(3.1, 7.4)));
    // 三組不同尺度的交錯樹冠球體簇（無迴圈）
    float c1 = max(0.0, sin(wp.x * 0.23 + sin(wp.y * 0.19) * 1.6) * cos(wp.y * 0.25 + cos(wp.x * 0.17) * 1.5));
    float c2 = max(0.0, sin((wp.x + wp.y) * 0.31 + 1.4) * cos((wp.x - wp.y) * 0.29 - 0.8));
    // 樹冠頂部細微枝葉碎形起伏
    float leafDetail = valueNoise(xz * 0.65) * 0.35 + valueNoise(xz * 1.45) * 0.18;
    float canopy = pow(max(c1, c2 * 0.85), 0.72) * (0.78 + leafDetail);
    return groveMask * canopy;
}
```

---

## 三、真實建築聚落、老街、廟宇與校園運動場 3D SDF 算子庫

### 1. Lipschitz 連續閩南紅磚街屋、穿堂巷弄與燕尾廟宇 (`evalTownhouseCluster`)
> [!CAUTION]
> 切勿使用不連續的 `fract()` 直接切割垂直牆面，否則在斜角光線步進時會產生嚴重的水平條紋偽影（Moiré Stepping）。以下算子採用平滑 `smoothstep` 屋身包絡線、留出橫向穿堂巷弄與中庭，並塑造斜屋頂馬背山牆與廟宇燕尾翹脊：

```glsl
// 回傳 vec3(buildingHeight: 建築高度, roofType: 1=紅瓦斜頂/2=青灰瓦/3=廟宇金紅燕尾, isFacade: 牆面遮罩)
vec3 evalTownhouseCluster(vec2 xz, float angleRad, float densityThreshold) {
    float c = cos(angleRad), s = sin(angleRad);
    vec2 uv = mat2(c, -s, s, c) * xz;
    // 街屋面寬 15m × 縱深 22m（中間預留巷弄與天井）
    vec2 lotScale = vec2(1.0 / 15.0, 1.0 / 22.0);
    vec2 lotId = floor(uv * lotScale);
    vec2 lotUV = fract(uv * lotScale) - 0.5;
    float hId = hash21(lotId);
    if (hId < densityThreshold) return vec3(0.0);

    // 平滑 Lipschitz 連續屋身平面（X 預留穿堂窄巷，Y 預留前後街廓間距）
    float wallX = smoothstep(0.47, 0.22, abs(lotUV.x));
    float wallY = smoothstep(0.42, 0.18, abs(lotUV.y));
    float footprint = wallX * wallY;
    if (footprint <= 0.001) return vec3(0.0);

    float floors = 1.0 + floor( fract(hId * 13.7) * 2.6 ); // 1 ~ 3 層樓街屋
    float baseH = floors * 3.1;
    // 雙坡斜屋頂與馬背山牆脊線
    float pitchedRoof = max(0.0, 1.0 - abs(lotUV.y) * 3.0) * 1.9;
    // 約 12% 機率生成傳統廟宇燕尾翹脊（屋脊兩端向上揚起）
    float isTemple = step(0.88, fract(hId * 31.3));
    float swallowtail = isTemple * pow(abs(lotUV.x) * 2.2, 2.0) * 2.1 * smoothstep(0.28, 0.0, abs(lotUV.y));

    float totalH = (baseH + pitchedRoof + swallowtail) * footprint;
    float roofType = isTemple > 0.5 ? 3.0 : (fract(hId * 7.3) > 0.42 ? 1.0 : 2.0);
    return vec3(totalH, roofType, footprint);
}
```
- **在 `v3_shade` 中的閩南老街著色技巧**：
  - 當 `p.y < roofThreshold`（立面牆身）時，以 `sin(p.x * 1.25) * cos(p.z * 1.25)` 產生一樓亭仔腳（騎樓拱廊）深色拱門陰影與窗格韻律，底色採用溫潤閩南紅磚色 `vec3(0.70, 0.31, 0.22)`。
  - 當 `p.y >= roofThreshold`（屋頂）時，依 `roofType` 區分傳統赤紅仰合瓦（疊加 `sin(p.x * 5.0)` 瓦溝陰影）、洗石子青灰屋瓦與廟宇琉璃金紅燕尾脊飾。

### 2. 學校校園建築群與紅藍 PU 跑道運動場 SDF（以金美國小為例）
適用於航線起點或聚落文教中心，在空中俯瞰極具辨識度：
```glsl
// 1. 校園 L 型教學大樓 + 雙坡斜屋頂 + 走廊柱列
vec2 scP = p.xz - schoolCenterXZ;
float wingMain = sdBox2D(scP - vec2(0.0, 38.0), vec2(58.0, 10.5));
float wingSide = sdBox2D(scP - vec2(-46.0, 8.0), vec2(11.0, 32.0));
float wingGym  = sdBox2D(scP - vec2(48.0, 12.0), vec2(14.0, 22.0));
float schoolDist = min(min(wingMain, wingSide), wingGym);
if (schoolDist < 3.5) {
    float wallProfile = smoothstep(3.2, 0.0, schoolDist);
    float roofRidge = max(0.0, 1.0 - abs(scP.y - 38.0) / 11.5) * 2.8 * smoothstep(2.0, -1.0, wingMain);
    float bldgH = 11.5 * wallProfile + roofRidge;
    if (useMicro && wallProfile > 0.4) {
        // 教學大樓外牆陽台與遮陽板水平韻律
        bldgH += sin(scP.x * 0.85) * 0.18;
    }
    h += bldgH;
    matID = 4.0;
}

// 2. 校園標準橢圓 PU 跑道、中央翠綠足球草皮與藍色籃球場
vec2 trP = scP - vec2(4.0, -18.0);
float trackStraight = sdBox2D(trP, vec2(32.0, 22.0)) - 18.0; // 圓角膠囊運動場外圈
float trackInner    = sdBox2D(trP, vec2(32.0, 22.0)) - 7.5;  // 內圈足球場邊界
float bballCourt    = sdBox2D(scP - vec2(-22.0, -18.0), vec2(14.0, 9.0)); // 旁側籃球場
```
- **在 `v3_shade` 中區分跑道與球場**：
  - `trackStraight < 0.0 && trackInner > 0.0`：塗刷磚紅 PU 跑道色 `vec3(0.76, 0.25, 0.18)`，並以 `sin(trackStraight * 3.4) > 0.82` 繪製清晰白色分道線！
  - `trackInner <= 0.0`：塗刷修剪整齊的翠綠足球草皮 `vec3(0.20, 0.48, 0.18)` 與橫向割草條紋。

---

## 四、海岸奇岩、漁港船舶、景觀拱橋與火山地貌 SDF 算子庫

### 1. 雙海蝕柱（燭台雙嶼）、基底連島暗礁與山頂雙層觀景涼亭（中正亭）
> [!WARNING]
> 計算潮間帶豆腐岩或海蝕平台帶狀遮罩 `shoreBand` 時，**必須使用未經 `max(0.0, ...)` 截斷的原始有號距離 `capeRaw`**，否則外海區域會全部落入遮罩範圍！

```glsl
// 1. 燭台雙嶼（雙海蝕岩柱：北嶼高 27m、南嶼高 22m + 頂部燭芯尖峰 + 底部暗礁平台）
float dStack1 = length(p.xz - vec2(4720.0, -340.0));
float dStack2 = length(p.xz - vec2(4645.0, -375.0));
float reefBridge = exp(-pow(length((p.xz - vec2(4685.0, -358.0)) * vec2(0.015, 0.024)), 2.0)) * 2.2;
float stack1 = max(0.0, 1.0 - pow(dStack1 / 25.0, 1.45)) * 27.0
             + exp(-dStack1 * dStack1 * 0.020) * 5.2;
float stack2 = max(0.0, 1.0 - pow(dStack2 / 21.0, 1.45)) * 22.0
             + exp(-dStack2 * dStack2 * 0.026) * 4.2;

// 2. 神祕海岸潮間帶正交豆腐岩（嚴格限制於未截斷 capeRaw 的崖腳潮間帶）
float shoreBand = smoothstep(-0.42, -0.10, capeRaw) * (1.0 - smoothstep(-0.08, 0.14, capeRaw));
if (shoreBand > 0.01) {
    float ang = 0.42;
    vec2 rUV = mat2(cos(ang), -sin(ang), sin(ang), cos(ang)) * p.xz;
    vec2 g = abs(fract(rUV * 0.24) - 0.5);
    float groove = smoothstep(0.40, 0.48, max(g.x, g.y));
    float tofuH = (1.15 - groove * 0.85) * shoreBand;
    h = max(h, tofuH);
    matID = 2.0;
}

// 3. 海岬山頂中正亭（雙層橘紅飛簷八角涼亭）
float pavDist = length(p.xz - pavilionCenterXZ);
if (pavDist < 18.0) {
    float basePlatform = smoothstep(16.0, 12.0, pavDist) * 1.8;
    float pillars      = smoothstep(9.5, 7.5, pavDist) * 3.8;
    float lowerEave    = max(0.0, 1.0 - abs(pavDist - 6.0) / 5.5) * 2.2;
    float upperRoof    = max(0.0, 1.0 - pavDist / 6.5) * 4.2;
    h += basePlatform + pillars + lowerEave + upperRoof;
    matID = 4.0;
}
```

### 2. 漁港雙防波堤、紅白導航燈塔、蹦火仔漁船與海底鐵泉池（磺港漁港與黃金之湯）
```glsl
// 1. 西側主防波堤與東側副防波堤 + 堤頭雙導航燈塔（高 12.5m / 10.5m）
float dWestJetty = sdSegment2D(p.xz, vec2(2680.0, -50.0), vec2(2520.0, -340.0));
float dEastJetty = sdSegment2D(p.xz, vec2(2360.0, -40.0), vec2(2435.0, -295.0));
float jettyH = max(
    smoothstep(13.0, 5.5, dWestJetty) * 3.8,
    smoothstep(11.0, 4.5, dEastJetty) * 3.4
);
float dLighthouseW = length(p.xz - vec2(2520.0, -340.0));
float dLighthouseE = length(p.xz - vec2(2435.0, -295.0));
float lighthouseH = max(
    smoothstep(6.5, 2.2, dLighthouseW) * 12.5,
    smoothstep(5.8, 2.0, dLighthouseE) * 10.5
);

// 2. 港內停泊與出港之「蹦火仔」磺火漁船船體與船艙
vec2 b1 = p.xz - vec2(2545.0, -195.0);
float hull1 = length(b1 * vec2(0.055, 0.14));
float cabin1 = length((b1 - vec2(3.5, 0.0)) * vec2(0.12, 0.22));
float boatH = smoothstep(1.0, 0.35, hull1) * 2.4 + smoothstep(1.0, 0.3, cabin1) * 2.2;

// 3. 潮間帶玄武岩砌石湧泉池（黃金之湯）
float dPool = length((p.xz - vec2(2760.0, -165.0)) * vec2(1.0, 1.35));
float stoneRim = exp(-pow((dPool - 28.0) / 4.2, 2.0)) * 1.45;
float innerDepression = smoothstep(26.0, 18.0, dPool) * 1.15;
```

### 3. 拋物線鋼拱跨海景觀橋與日式木造溫泉足湯亭（員潭溪景觀橋與大鵬足湯）
```glsl
// 1. 員潭溪口拋物線鋼拱景觀橋（橋面拱起 + 雙側高聳拋物線鋼拱肋 + 橋塔墩座）
vec2 brP = p.xz - vec2(1380.0, -75.0);
if (abs(brP.x) < 115.0 && abs(brP.y) < 18.0) {
    float spanNorm = clamp(brP.x / 98.0, -1.0, 1.0);
    float parabola = max(0.0, 1.0 - spanNorm * spanNorm);
    float deckProfile = smoothstep(9.5, 5.5, abs(brP.y));
    float deckH = (2.6 + parabola * 6.8) * deckProfile;
    // 雙側鋼拱肋（位於橋面兩側 abs(brP.y) ≈ 6.2m）
    float ribMask = exp(-pow((abs(brP.y) - 6.2) / 1.45, 2.0)) * step(abs(spanNorm), 0.92);
    float archRibH = (3.0 + parabola * 17.5) * ribMask;
    // 兩端橋台墩座
    float abutment = exp(-pow((abs(brP.x) - 88.0) / 7.5, 2.0)) * deckProfile * 5.2;
    h = max(h, max(deckH, archRibH) + abutment);
    matID = 4.0;
}

// 2. 大鵬足湯公園日式木造斜頂涼亭群（雙座檜木亭 + 砌石溫泉泡腳池）
vec2 pav1 = p.xz - vec2(1210.0, 125.0);
vec2 pav2 = p.xz - vec2(1265.0, 155.0);
float dPav1 = max(abs(pav1.x) * 0.75, abs(pav1.y));
float dPav2 = max(abs(pav2.x) * 0.75, abs(pav2.y));
float dPav  = min(dPav1, dPav2);
if (dPav < 18.0) {
    float woodDeck = smoothstep(17.0, 13.0, dPav) * 0.85;
    float hipRoof  = max(0.0, 1.0 - dPav / 14.5) * 6.2;
    h += woodDeck + hipRoof;
    matID = 4.0;
}
```

### 4. 背山面海之火山群、放射狀安山岩蝕溝與硫磺噴氣崩壁（大屯火山群與竹子山）
當區域背靠高聳山脈時，必須使用 `volcanoBlend` 將背景山體與平地農田平滑解耦，避免山坡出現農田格線：
```glsl
float volcanoMask = smoothstep(260.0, 1450.0, p.z);
float volcanoBlend = smoothstep(0.08, 0.35, volcanoMask);
if (volcanoMask > 0.001) {
    // 竹子山主峰 + 七星山/大屯山雙錐體 + 放射狀安山岩深蝕溝
    float zhuziPeak  = exp(-pow((p.x - 4200.0) / 3600.0, 2.0)) * 225.0;
    float qixingPeak = exp(-pow((p.x - 8600.0) / 2900.0, 2.0)) * 265.0;
    float gullies    = ridgedNoise(p.xz * 0.0022) * 58.0 + fbm3(p.xz * 0.0065) * 24.0;
    // 小油坑/庚子坪火山爆裂口凹陷崩壁
    float craterDist = length((p.xz - vec2(8200.0, 1080.0)) * vec2(1.0, 1.4));
    float craterCarve = smoothstep(420.0, 90.0, craterDist) * 48.0;
    float vH = (zhuziPeak + qixingPeak + gullies) * volcanoMask - craterCarve;
    h += vH;
    if (volcanoBlend > 0.35) {
        matID = (craterDist < 280.0) ? 2.0 : 5.0; // 崩壁硫磺裸岩 vs 火山箭竹林相
    }
}
```

### 5. 山城階梯紅燈籠聚落、層疊礦業選煉廠遺址與陰陽海（以九份、金瓜石、水湳洞為例）
當目標為依山傍海之礦山山城時，必須在陡峭山腰上透過等高線階梯化（Terraced Stepping）結合 `evalTownhouseCluster` 與豎崎路紅燈籠發光帶：
```glsl
// 1. 水湳洞十三層選煉廠遺址（依山坡逐層退縮之 13 階巨型混凝土地基與長煙道）
vec2 r13 = p.xz - ruinsCenterXZ;
if (abs(r13.x) < 160.0 && r13.y > -120.0 && r13.y < 140.0) {
    float tierIdx = floor(clamp((r13.y + 120.0) / 20.0, 0.0, 12.0));
    float tierWidth = 145.0 - tierIdx * 6.5;
    float tierMask = smoothstep(tierWidth, tierWidth - 8.0, abs(r13.x));
    float fluePipe = exp(-pow((abs(r13.x - 35.0) - tierIdx * 2.5) / 4.5, 2.0)) * 2.4; // 廢煙道爬山管線
    h += (tierIdx * 4.2 + 3.5) * tierMask + fluePipe;
    matID = 4.0;
}

// 2. 九份豎崎路石階與阿妹茶樓紅燈籠夜景發光帶（於 v3_shade 疊加暖紅燈籠光暈）
float shuqiRoad = exp(-pow((p.x - jiufenSpineX - sin(p.z * 0.015) * 18.0) / 5.5, 2.0));
float lanternPulse = 0.75 + 0.25 * sin(p.z * 1.8);
vec3 lanternGlow = vec3(1.35, 0.28, 0.08) * shuqiRoad * lanternPulse;
```

---

## 五、雙尺度分析法線與光線步進優化 (`calcTerrainNormal` & 3-Step Binary Search)

為兼顧高速編譯與微觀立體度，請採用以下標準光線步進與三點法線計算模式：

```glsl
// 1. 雙尺度法線：共用中心點 hCenter，僅需額外 2 次微地形採樣即可獲得銳利法線
vec3 calcTerrainNormal(vec3 p, float t) {
    float eps = mix(0.10, 0.55, clamp(t / 900.0, 0.0, 1.0));
    float hC = evaluateTerrain(p, true).x;
    float hX = evaluateTerrain(p + vec3(eps, 0.0, 0.0), true).x;
    float hZ = evaluateTerrain(p + vec3(0.0, 0.0, eps), true).x;
    return normalize(vec3(hC - hX, eps, hC - hZ));
}

// 2. 主光線步進使用 useMicro = false，命中後執行 3 步 useMicro = true 二元搜尋
for (int i = 0; i < 76; i++) {
    vec3 p = ro + rd * t;
    vec2 res = evaluateTerrain(p, false);
    float d = p.y - res.x;
    if (d < 0.002 * t + 0.02) {
        float tA = prevT, tB = t;
        for (int b = 0; b < 3; b++) {
            float tMid = 0.5 * (tA + tB);
            vec3 pMid = ro + rd * tMid;
            if (pMid.y < evaluateTerrain(pMid, true).x) tB = tMid;
            else tA = tMid;
        }
        tHit = 0.5 * (tA + tB);
        hitMat = evaluateTerrain(ro + rd * tHit, true).y;
        hit = true;
        break;
    }
    prevT = t;
    t += max(0.32, d * 0.52);
    if (t > maxDist) break;
}
```
