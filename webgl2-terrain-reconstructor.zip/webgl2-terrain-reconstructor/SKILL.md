---
name: webgl2-terrain-reconstructor
description: >-
  基於 Leonxlnx/napali 零外部資產（Zero-Asset）架構的「程序化三維地景在地化重構技能包」。當使用者指定任何地理區域、縣市鄉鎮、海岸山脈、國家公園、流域、Google Maps 航線網址或提供地景企劃，要求「產生 WebGL2 三維地景系統」、「在地化重構 napali」、「建立程序化航拍地景 HTML」時，必須立即啟用此技能。技能內建互動式地理考證與 Google Maps 多航點解析引導、六區宏觀座標分區（Macro-Zoning）、航線視線對齊（Camera-to-Landmark Framing）、真實建築聚落與地標 3D SDF 建模、無迴圈快速編譯自然樹冠與非週期地籍扭曲、多重物理水體光學、大氣散射、2D SDF 雷達瞬移、SPP=16 超取樣與四層空間自然聲景，並透過自動化腳本與六區無頭截圖驗證視覺寫實度與程式碼完整性。
---

# WebGL2 程序化三維地景在地化重構技能包 (`webgl2-terrain-reconstructor`)

本技能將 `Leonxlnx/napali` 的五大微著色器管線（`v2_sky`, `v3_geo`, `v3_shade`, `v3_water`, `v1_post`）與台灣在地化高寫實度重構實戰經驗（大北門鹽分地帶、金山山海環狀線），提煉為一套**一次產出最高品質、具備極致微觀細節、豐富人文自然地標與真實地理現況重現**的標準化開發與驗證工作流。

---

## 依賴、參考文件與黃金範本（Skill Resources）

- **地貌、自然林相與建築地標 3D SDF 算子圖鑑**：請參閱 [references/geomorphology_sdf_atlas.md](./references/geomorphology_sdf_atlas.md)。
- **水體光學、衝浪碎浪泡沫與大氣散射指南**：請參閱 [references/water_sky_optics_guide.md](./references/water_sky_optics_guide.md)。
- **三列式玻璃擬態 HUD、2D SDF 雷達與四層空間聲景規範**：請參閱 [references/ui_hud_and_soundscape_spec.md](./references/ui_hud_and_soundscape_spec.md)。
- **六區空間、航點視線對齊與光學規劃藍圖樣板**：請參閱 [templates/region_blueprint_template.json](./templates/region_blueprint_template.json)。
- **黃金實作參考範本（完整單一 HTML 骨架與 GLSL 實作）**：請參閱 [examples/webgl2_jinshan_coast_reference.html](./examples/webgl2_jinshan_coast_reference.html)。
- **自動化靜態結構與寫實度驗證腳本**：請使用 [scripts/validate_terrain_html.py](./scripts/validate_terrain_html.py)。
- **無頭瀏覽器六區全航段截圖巡檢腳本**：請使用 [scripts/inspect_render.mjs](./scripts/inspect_render.mjs)（或 CommonJS 版 [scripts/inspect_render.js](./scripts/inspect_render.js)）。

---

## 一、地景視覺寫實度與真實現況重現「十二大鐵律」（Mandatory Realism Rules）

在撰寫任何 GLSL 程式碼前，必須無條件遵守以下十二大寫實度與工程鐵律，嚴禁產出「貼圖式平地、重複格線、單調水泥塊、高空順光慘白或地標被遮擋」的半成品：

1. **鐵律一：破除笛卡兒棋盤格（Anti-Grid Domain Warping）**
   - 任何農田、梯田、養殖池、建築街廓或岩層，**絕對禁止**直接使用 `sin(p.x) * sin(p.z)` 或正交 `mod(p.xz, size)`。
   - **強制要求**：必須經過雙頻非週期空間扭曲（`evalIrregularParcel`）或 2x2 Voronoi 晶胞分割（`fastVoronoi2x2`），使每一塊地籍/池區呈現自然歪斜、大小不一且帶導角邊界的真實航拍拼布感。

2. **鐵律二：真實水系曲流與負向幾何開槽（True Hydrology & Negative-Space Carving）**
   - 河流、溪谷、潮溝、大圳與海蝕溝**絕對禁止**只塗上藍色材質而不改變地形高度。
   - **強制要求**：必須定義專屬中心線函數（如 `getRiverCenterZ(x)`），在 `evaluateTerrain` 中執行**負向高度開槽（Negative-Space Carving）**切穿陸地至水面（`Y = 0.0m`）以下，並於凹岸/凸岸塑造非對稱坡度、乾濕礫石沙洲、潮間帶泥灘與梯形防汛堤防或砌石護岸。

3. **鐵律三：微觀高度場與雙尺度分析法線解耦（Micro-Relief & Dual-Scale Analytic Normals）**
   - 宏觀地形之上必須疊加微觀紋理：耕地犁溝（`18cm`）、沙丘風成沙紋、層狀砂頁岩互層、柱狀玄武岩節理、屋瓦溝槽、石板路縫或礁石孔洞。
   - **強制要求**：主要光線步進迴圈使用 `evaluateTerrain(p, false)` 保持大步距高速收斂；命中後的**三步二元搜尋（3-step Binary Search）**與法線計算 `calcTerrainNormal(p, t, hCenter)` 必須啟用 `evaluateTerrain(p, true)`，結合三點採樣（共用 `hCenter` + X/Z 雙偏移）解析微表面凹凸，並在 `v3_shade` 疊加程序化微法線擾動（Micro-normal Perturbation）。

4. **鐵律四：每個地理分區至少具備 3 個真實地標級 3D SDF 實體（Signature 3D Landmarks）**
   - 僅靠噪聲山脈無法讓使用者認出真實地點。每個分區（Zone 1 ~ Zone 6）必須考證並實作 **3 個以上**具代表性的真實立體地標或微地貌（例如：國小校園與紅藍 PU 操場跑道、閩南紅磚拱廊老街與燕尾廟宇、山城階梯紅燈籠與十三層選煉廠遺址、海岬雙燭台海蝕柱與豆腐岩、漁港雙防波堤燈塔與蹦火仔漁船、拋物線鋼拱景觀橋與日式木造足湯涼亭、火山爆裂口硫磺崩壁等），並指派獨立 `matID` / `subMask` 與專屬 PBR/SSS 材質。

5. **鐵律五：水體光學分區調變與潮間帶動態泡沫（Spatially-Varying Water & Surf Foam Optics）**
   - 嚴禁全地圖共用單一海浪與單一水色。必須依據座標分區與水深 `waterDepth` 動態混合：
     - **外海/海灣湧浪區**：非對稱尖峰湧浪（`pow(max(0.0, sin(swellPhase)), 5.0)`）搭配受碎形噪聲調變的碎浪泡沫網（`surfRollerFoam`），嚴禁出現均勻正弦斑馬紋；
     - **海蝕柱/暗礁激浪區**：繞射同心圓碎浪白沫環（`twinBreaker`）與貼齊礁岩根部（`waterDepth < 0.32m`）的拍岸浪花；
     - **河溪/濕地/鹽田/溫泉/礦物海灣區**：平緩流紋、高鏡面反射、礦物滷水染色，或海底溫泉/陰陽海金黃鐵泉湧泉熱羽流（`thermalPlume`）與漁船/山城燈火倒影（`boatGlow`）。

6. **鐵律六：午後黃金斜射光與漸進式遠景瑞利大氣透視（Golden-Afternoon Oblique Sun & Crisp Aerial Perspective）**
   - 預設太陽仰角嚴禁設在正午高空（`> 35°` 會導致 `NdotL ≈ 1.0`，山脈、屋脊與田埂完全失去立體陰影且大氣散射過曝慘白）。
   - **強制要求**：預設太陽仰角必須設定於 **`7.0° ~ 19.0°`**（斜射黃金光或夕照），搭配深鈷藍天頂與**延遲啟動（`max(0.0, t - 180.0)`）的大氣透視霧化係數**，確保近中景建築與植被色彩濃郁、遠景火山或高山稜線保有立體陰影與崩壁細節。

7. **鐵律七：航線運鏡與宏觀座標 100% 同步（Synchronized Spline Flight & Macro-Zoning）**
   - 120 秒航線的每一秒位置，必須與 6 大地理分區座標、HUD 分區標題、底部 6 顆快速跳轉按鈕（`1~6` 鍵）以及左側 2D SDF 雷達圖上的航點完全對齊。

8. **鐵律八：零外部資產與全功能 HUD 一次到位（Zero-Asset Self-Contained Architecture）**
   - 單一 `.html` 內建完整 WebGL2 渲染管線、不重疊三列式玻璃擬態 HUD、可點擊瞬移之 2D SDF 雷達圖、`SPP=16` Halton 超取樣靜態渲染器、GLSL 五大模組剖析視窗與 Web Audio API 四層動態自然聲景合成器。

9. **鐵律九：航線視線對齊與海岬外側掠飛構圖（Camera-to-Landmark Framing & Line-of-Sight Alignment）**
   - **嚴禁將地標擺在起飛點後方或被山頭樹林遮擋的死角**！在定位任何地標（學校、老街、拱橋、海蝕柱、涼亭、漁港）時，必須先計算該分區代表時間點 `t_zone` 的攝影機座標 `camPos(t_zone)` 與視線前向向量 `forward = normalize(lookAt - camPos)`，將地標精確配置於**攝影機正前方 `100m ~ 300m` 的視野核心區**。
   - **海岬航段構圖準則**：飛越突出海岬（如獅頭山、鼻頭角、鵝鑾鼻）時，無人機航線必須沿**海岬外海側斷崖邊緣**飛行並朝向海蝕柱與峭壁取景，嚴禁從內陸樹冠上方直視海面導致前景樹木遮蔽海岸地標。

10. **鐵律十：Lipschitz 連續建築聚落 SDF 與無迴圈自然樹冠（Lipschitz-Continuous Architecture & Loop-Free Organic Trees）**
    - **建築街廓嚴禁使用不連續 `fract()` 垂直切面**：直接用 `fract()` 切割方塊會破壞距離場 Lipschitz 連續性，在斜視角產生嚴重水平條紋偽影（Raymarching Moiré Stepping）。必須使用 `evalTownhouseCluster`（平滑 `smoothstep` 屋身輪廓 + 橫向穿堂巷弄 + 斜屋頂馬背山牆 + 廟宇燕尾翹脊）並搭配 **3 步二元搜尋（Binary Search Refinement）**消除階梯偽影。
    - **植被嚴禁使用正弦圓球顆粒（Pineapple Bumps）**：防風林、丘陵闊葉林與海岸灌木必須使用無迴圈之 `evalNaturalTreeCanopy`（結合 `fastDomainWarp` 雙頻空間扭曲 + 三頻交錯樹冠簇 + 碎形葉簇微凹凸），在山坡、河岸與老街外圍形成自然疏密交錯的蒼翠林相。

11. **鐵律十一：火山/高山背景漸進混合與潮間帶無截斷遮罩（Mountain Backdrop Blending & Unclamped Intertidal Masking）**
    - **高山與平原農田平滑解耦**：當背景具有高聳山脈或火山群（如大屯山、基隆山、無耳茶壺山、中央山脈）時，必須定義平滑過渡遮罩 `volcanoBlend`，在山麓高度以上完全關閉平地農田格線與村落屋舍，切換為安山岩/玄武岩放射狀蝕溝、箭竹芒草坡與崩壁硫磺煙氣。
    - **潮間帶地貌嚴禁傳入截斷後距離值**：計算海蝕平台、豆腐岩或潮間帶礁岩帶狀遮罩 `shoreBand` 時，**必須傳入未經 `max(0.0, ...)` 截斷的原始有號距離 `capeRaw`**（例如 `smoothstep(-0.42, -0.10, capeRaw) * (1.0 - smoothstep(-0.08, 0.15, capeRaw))`），嚴禁傳入截斷後的 `capeBody` 導致整片外海被誤判為潮間帶而佈滿方格或白沫。

12. **鐵律十二：Windows ANGLE D3D11 (`fxc.exe`) 秒級編譯優化與六區無頭視覺巡檢（Fast-Compile GLSL & Multi-Zone Inspection）**
    - Windows Chrome 的 ANGLE D3D11 後端（`fxc.exe`）在展開 `evaluateTerrain` 內的巢狀 `for` 迴圈時，若輔助噪聲函數含有迴圈且被重複呼叫，會引發超過 40 秒的編譯卡頓。
    - **強制工程優化**：
      1. `fbm3`、`ridgedNoise`、`fastVoronoi2x2` 與 `evalNaturalTreeCanopy` **必須完全展開為無 `for` 迴圈之直線算式（Loop-Free Unrolled Expressions）**；
      2. 在 `evaluateTerrain(p, useMicro)` 頂部**一次性預計算共用基底**（`sharedParcel`、`sharedHouse`、`sharedTree`），供各分區直接取用；
      3. 主光線步進上限設為 `76` 步（呼叫 `evaluateTerrain(p, false)`），命中後執行 3 步二元搜尋（呼叫 `evaluateTerrain(pMid, true)`），確保著色器在 **1.5 秒內完成編譯且維持 60 FPS**。

---

## 二、標準執行工作流（Step-by-Step Execution Workflow）

當使用者觸發本技能時，請依序執行以下四個階段：

### 階段 1：地理考證、Google Maps 航線解析與互動式企劃確認（Geomorphological Discovery & Route Resolution）

1. **解析使用者輸入（支援地點名稱或 Google Maps 網址）**：
   - **若使用者提供 Google Maps 短網址（如 `https://maps.app.goo.gl/...`）或路線網址**：
     - 立即透過 `curl -sI -L "<URL>"` 解析重導向後的完整 Google Maps `/dir/` 網址，提取所有途經航點名稱與經緯度座標（Waypoints & Coordinates）。
     - 若航點為具體地標（例如：國小、老街、海蝕柱、漁港、足湯公園），自動考證各航點的真實地理方位（沿海、內陸、台地、河口、山麓）、建築特徵與周邊水文地貌。
   - **若使用者僅提供模糊地名（例如：「幫我做太魯閣國家公園」、「做九份、金瓜石」）**：
     - 先運用地理知識整理出該區域最具代表性的 **6 個連續地理分區（由起點至終點或環狀迴圈）**、**主要水系/海岸線走向**、**最佳斜射光影時刻**與**各區 3 大標誌性地標**。
     - 若有需要確認使用者偏好，可使用 `ask_question` 工具簡潔詢問，或直接依據最經典的真實地理路線推進。

2. **建立區域地景重構藍圖（Region Blueprint）**：
   - 讀取 [templates/region_blueprint_template.json](./templates/region_blueprint_template.json) 結構，規劃：
     - 世界座標範圍與背景山脈範圍。
     - 120 秒航線 Spline 控制點（`CAM_PTS` 與 `LOOK_PTS`），**逐一檢驗每個分區代表秒數（如 `t = 5, 14, 32, 52, 72, 92`）的攝影機視線向量是否正對該區核心地標（距離 `100m ~ 300m`）且無遮擋**。
     - 六大宏觀分區（`Zone 1 ~ Zone 6`）的座標權重函數 `getZoneMasks(p)`、地質高度算子、材質 ID（`matID`）與水體光學參數。

---

### 階段 2：五大微著色器與 SDF 地貌庫設計（Shader Pipeline Engineering）

在撰寫 GLSL 前，請查閱：
- **地貌與建築 SDF 算子圖鑑**：[references/geomorphology_sdf_atlas.md](./references/geomorphology_sdf_atlas.md)
- **水體光學與大氣散射指南**：[references/water_sky_optics_guide.md](./references/water_sky_optics_guide.md)
- **黃金實作參考範本**：[examples/webgl2_jinshan_coast_reference.html](./examples/webgl2_jinshan_coast_reference.html)

依序實作並整合五大 GLSL 模組：

1. **`v2_sky`（Preetham + Rayleigh-Mie 大氣散射與程序化雲層）**：
   - 實作 `computeSkyAndClouds(rd, sunDir, fullClouds)`：支援午後黃金斜陽或地平線夕陽（`sunEl = 7° ~ 19°`）、高空卷雲、立體積雲與地平線暖金霞光。
2. **`v3_geo`（多頻高度場、水系負向開槽、無迴圈樹冠與真實建築地標 SDF）**：
   - 實作無迴圈 `fbm3`、`ridgedNoise`、`fastVoronoi2x2`、`evalIrregularParcel`、`evalTownhouseCluster` 與 `evalNaturalTreeCanopy`。
   - 實作區域專屬水系中心線函數，在 `evaluateTerrain(vec3 p, bool useMicro)` 中整合：
     - 頂部一次性預計算 `sharedParcel`、`sharedHouse` 與 `sharedTree`；
     - 6 大地理分區的宏觀高度場、負向水系開槽、微觀紋理與 **每區 3+ 個立體地標 SDF**；
     - 回傳 `vec4(totalH, waterLevel, matID, subMask)`。
   - 實作雙尺度分析法線 `calcTerrainNormal(vec3 p, float tDist, float hCenter)`。
3. **`v3_shade`（材質分類器、微法線擾動、次表面散射與斜射光影）**：
   - 針對每一個 `matID` 與 `subMask` 實作細膩的程序化色彩與微法線：
     - **植被/防風林/草坡**：雙向次表面散射（Back-lit SSS）+ 絲絨邊緣反光（Velvet Rim）+ 樹冠明暗團塊；
     - **建築/老街/校園/橋樑**：閩南紅磚拱廊韻律、青灰瓦當斜屋頂、廟宇燕尾金飾、PU 跑道白線與足球場草皮標線、拋物線鋼拱肋與木造格柵；
     - **海岸岩層/豆腐岩/火山崩壁**：傾動砂頁岩互層紋理、正交節理刻溝、潮間帶綠石蓴覆蓋、硫磺結晶與蒸氣羽流；
     - **大氣透視**：採用延遲距離霧化 `max(0.0, t - 180.0)`，確保遠山與近景皆層次分明。
4. **`v3_water`（多區水體波浪法線、菲涅耳反射、碎浪泡沫網與溫泉/火光光學）**：
   - 實作 `shadeWaterSurface(...)`：依據分區動態切換衝浪灣非對稱湧浪與碎形泡沫網（`surfRollerFoam`）、海蝕柱同心圓激浪環（`twinBreaker`）、潮間帶拍岸白沫（`waterDepth < 0.32m`）、海底鐵泉/陰陽海金黃熱羽流（`thermalPlume`）、漁港蹦火仔火光倒影（`boatGlow`）與內陸溪流平緩波紋。
5. **`v1_post`（ACES Filmic 色調映射、太陽眩光與邊緣暗角）**：
   - 實作 `acesToneMap(x)` 曲線與 Gamma 校正。

---

### 階段 3：三列式 HUD、2D SDF 雷達與四層空間聲景組裝（Frontend & Audio Integration）

請查閱 [references/ui_hud_and_soundscape_spec.md](./references/ui_hud_and_soundscape_spec.md)，確保單一 HTML 檔案完整包含：
1. **三列式全視窗 Flex 佈局 (`#hudContainer`)**：頂部遙測與功能列、中段左右側邊欄（左：2D SDF 雷達 + 分區資訊卡；右：8 組光學滑桿 + 3 組開關 + URL 狀態複製）、底部 120 秒時間軸與 6 顆分區快速跳轉鈕（`1 ~ 6` 鍵）。
2. **2D 符號距離場雷達 (`#sdfRadarCanvas`)**：離線掃描世界座標繪製海陸、水系、聚落、山脈與地標色塊，疊加航線虛線與無人機視錐，支援點擊瞬移。
3. **SPP=16 次像素 Halton 超取樣靜態渲染器**：支援 `?mode=still&spp=16` 與按鈕切換。
4. **Web Audio API 四層動態自然聲景**：粉紅噪聲海浪/溪流 LFO、帶通微風草浪聲、溫暖環境泛音和弦、隨機五聲音階立體聲鳥鳴。
5. **同步撰寫詳盡的《程序化三維地景重構指南.md》**：記錄六區地貌表、地標數學模型、航線時間軸與操作說明。

---

### 階段 4：自動化靜態驗證與六區無頭瀏覽器視覺巡檢（Automated Verification & Multi-Zone Inspection）

產出 HTML 檔案後，**絕對禁止未經測試即交付使用者**。必須依序執行本技能內建的兩支驗證腳本（位於技能目錄下的 `scripts/`）：

1. **執行結構與 GLSL 完整性靜態檢查 (`validate_terrain_html.py`)**：
   ```powershell
   python <skill_dir>/scripts/validate_terrain_html.py <輸出的HTML檔案路徑>
   ```
   - 確認 28 項結構、GLSL 關鍵算子、雙尺度二元搜尋、HUD 元件與聲景檢查 **100% 通過**。

2. **執行 Headless Chrome 六區全航段截圖與 WebGL2 編譯驗證 (`inspect_render.mjs`)**：
   ```powershell
   node <skill_dir>/scripts/inspect_render.mjs <輸出的HTML檔案路徑> <輸出截圖前綴路徑.png> --all-zones
   ```
   - 此腳本會自動啟動本機 Chrome/Edge，驗證 WebGL2 Program Link 成功且無任何 Console/Page Error，並自動隱藏 HUD 於單一瀏覽器工作階段內切換時間軸至 **6 大分區代表時間點** 擷取高解析度截圖。
   - **關鍵自我檢視（Self-Critique with `read_file`）**：
     - 務必使用 `read_file` 逐張檢視擷取出的 6 張分區截圖！
     - 檢查每一區：
       1. **核心地標是否清晰出現在畫面正前方且未被樹木或地形遮擋？**
       2. **建築聚落是否具備斜屋頂、巷弄與真實色彩，且牆面無水平條紋偽影？**
       3. **海岸、碎浪、沙灘、農田與遠山是否具備豐富微觀層次與斜射立體光影？**
     - 若發現任何一區地標偏離視野、畫面單調或光影過曝，立即修正 GLSL 與攝影機控制點並重新截圖驗證，直到 6 區畫面皆達到真實航拍級品質為止。
